package com.example.app;

import java.sql.Connection;
import java.sql.DriverManager;

public class database {
    //Set the connection with the DataBase
    public static Connection connectDb() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:8001/users","root","");
            return connect;
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }
}
