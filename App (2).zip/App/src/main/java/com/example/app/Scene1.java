package com.example.app;

import javafx.fxml.FXML;

import java.io.IOException;

public class Scene1 {

    @FXML
    private void Login() throws IOException {
        HelloApplication1.setRoot("Scene2");
    }
}
